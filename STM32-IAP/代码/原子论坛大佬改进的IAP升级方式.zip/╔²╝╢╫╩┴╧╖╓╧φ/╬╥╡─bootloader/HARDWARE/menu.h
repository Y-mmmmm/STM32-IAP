#ifndef __MENU_H
#define __MENU_H

#include "flash_if.h"

typedef  void (*pFunction)(void);

void Main_Menu(void);


#endif  /* __MENU_H */

