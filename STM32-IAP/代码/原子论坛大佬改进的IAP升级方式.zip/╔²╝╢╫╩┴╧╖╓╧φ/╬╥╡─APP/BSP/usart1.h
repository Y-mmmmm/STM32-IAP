#ifndef _USART1_H
#define _USART1_H

#include "stm32f0xx.h"
#include <stdio.h>

extern volatile unsigned char updata_pro;

//�ӿڶ���
void USART1_Init(uint16_t baud);


#endif



